package com.example.Car1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Car1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
